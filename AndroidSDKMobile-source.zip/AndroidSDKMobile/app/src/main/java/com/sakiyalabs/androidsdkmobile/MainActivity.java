package com.sakiyalabs.androidsdkmobile;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Typeface;

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.tukaani.xz.XZInputStream;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_ARCHIVE = 71;
    private LinearLayout content;
    private TextView status;
    private TextView listing;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 36, 28, 28);
        page.setBackgroundColor(0xFF101820);

        TextView title = new TextView(this);
        title.setText("Android SDK Mobile");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Native Android SDK archive manager · Preview 0.1.0");
        subtitle.setTextColor(0xFFB8C7D9);
        subtitle.setTextSize(13);
        subtitle.setPadding(0, 8, 0, 24);
        page.addView(subtitle);

        Button importButton = new Button(this);
        importButton.setText("Import SDK archive (.tar.xz)");
        importButton.setOnClickListener(v -> chooseArchive());
        page.addView(importButton);

        status = new TextView(this);
        status.setText("No archive selected.\n\nImport the SDK archive to inspect its contents.");
        status.setTextColor(0xFFEAF2F8);
        status.setTextSize(15);
        status.setPadding(0, 24, 0, 16);
        page.addView(status);

        TextView warning = new TextView(this);
        warning.setText("PORTING STATUS\nThe uploaded package targets Linux ARM64/musl. Android uses Bionic. Listing files does not mean its executables can run on Android. Each tool must be compatibility-tested or rebuilt for Android.");
        warning.setTextColor(0xFFFFD08A);
        warning.setTextSize(14);
        warning.setPadding(16, 16, 16, 16);
        warning.setBackgroundColor(0xFF26313B);
        page.addView(warning);

        listing = new TextView(this);
        listing.setTextColor(0xFFD7E2EC);
        listing.setTextSize(12);
        listing.setTypeface(Typeface.MONOSPACE);
        listing.setPadding(0, 20, 0, 20);
        page.addView(listing);

        TextView footer = new TextView(this);
        footer.setText("Planned modules: Archive Manager · Tool Compatibility · SDK Components · Build Workspace");
        footer.setTextColor(0xFF8FA3B8);
        footer.setTextSize(12);
        footer.setPadding(0, 24, 0, 0);
        page.addView(footer);

        scroll.addView(page);
        setContentView(scroll);
    }

    private void chooseArchive() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PICK_ARCHIVE);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_ARCHIVE || result != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try {
            getContentResolver().takePersistableUriPermission(uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}
        status.setText("Reading archive…");
        new Thread(() -> inspectArchive(uri)).start();
    }

    private void inspectArchive(Uri uri) {
        List<String> entries = new ArrayList<>();
        int count = 0;
        long totalBytes = 0;
        String error = null;
        try (InputStream raw = getContentResolver().openInputStream(uri);
             XZInputStream xz = new XZInputStream(raw);
             TarArchiveInputStream tar = new TarArchiveInputStream(xz)) {
            TarArchiveEntry entry;
            while ((entry = tar.getNextTarEntry()) != null) {
                count++;
                totalBytes += Math.max(0, entry.getSize());
                if (entries.size() < 120) {
                    entries.add((entry.isDirectory() ? "[DIR] " : "[FILE] ") + entry.getName());
                }
            }
        } catch (Exception e) {
            error = e.getClass().getSimpleName() + ": " + e.getMessage();
        }
        final int finalCount = count;
        final long finalBytes = totalBytes;
        final String finalError = error;
        final String output = String.join("\n", entries);
        runOnUiThread(() -> {
            if (finalError != null) {
                status.setText("Could not read archive:\n" + finalError);
                listing.setText("");
            } else {
                status.setText("Archive inspected successfully\nEntries: " + finalCount +
                        "\nUncompressed file size total: " + finalBytes + " bytes");
                listing.setText("FIRST ENTRIES\n\n" + output +
                        (finalCount > entries.size() ? "\n… more entries omitted from preview" : ""));
            }
        });
    }
}
